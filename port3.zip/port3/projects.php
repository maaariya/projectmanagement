<?php

include 'connectdb.php';

// Function to search projects by name
function searchProjectsByName($searchTerm, $conn) {
    // Prepare the query to prevent SQL injection
    $query = "SELECT * FROM projects WHERE title LIKE ?";
    $stmt = mysqli_prepare($conn, $query);
    $searchTerm = '%' . $searchTerm . '%';
    mysqli_stmt_bind_param($stmt, "s", $searchTerm);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $projects = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $projects[] = $row;
    }
    
    return $projects;
}

// Function to search projects by start date
function searchProjectsByStartDate($searchTerm, $conn) {
    // Prepare the query to prevent SQL injection
    $query = "SELECT * FROM projects WHERE start_date = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $searchTerm);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $projects = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $projects[] = $row;
    }
    
    return $projects;
}

// Check if form submission or AJAX request is made
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['searchType'], $_POST['search'])) {
        $searchType = $_POST['searchType'];
        $searchTerm = $_POST['search'];

        if ($searchType === 'name') {
            $projects = searchProjectsByName($searchTerm, $conn);
        } elseif ($searchType === 'startDate') {
            $projects = searchProjectsByStartDate($searchTerm, $conn);
        }

        echo json_encode($projects);
        exit();
    }
}
?>
