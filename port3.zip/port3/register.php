<?php

if(isset($_POST['submitted'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    
    if(empty($username) || empty($password)) {
        echo "Error: Username and password cannot be empty.";
    } else {

        include 'connectdb.php';
        

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        

        $stmt = $db->prepare("INSERT INTO users (username, password, email) VALUES (:username, :password, :email)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':email', $email);
        
        if($stmt->execute()) {

            $user_id = $db->lastInsertId();
            // Redirect to register_success.html
            header("Location: register_success.html?user_id=$user_id");
            exit();
        } else {

            echo "Error: Unable to register. Please try again.";
        }
    }
}
?>
