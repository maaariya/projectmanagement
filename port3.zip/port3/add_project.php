<?php

$servername = "localhost";
$username = "u-230413184";
$password = "zesaDrN9pdmCaOT";
$dbname = "u_230413184_db";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$title = $_POST['title'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$phase = $_POST['phase'];
$description = $_POST['description'];


$user_username = "user1";
$user_email = "user1@example.com";

$user_sql = "INSERT INTO users (username, password, email) VALUES ('$user_username', 'password', '$user_email')";

if ($conn->query($user_sql) === TRUE) {
    $user_id = $conn->insert_id;

    $project_sql = "INSERT INTO projects (title, start_date, end_date, phase, description, uid) 
                    VALUES ('$title', '$start_date', '$end_date', '$phase', '$description', '$user_id')";

    if ($conn->query($project_sql) === TRUE) {
        $project_id = $conn->insert_id;
        header("Location: success_page1.html?project_id=$project_id");
        exit();
    } else {
        header("Location: error_page.html");
        exit();
    }
} else {
    header("Location: error_page.html");
    exit();
}

$conn->close();
?>
