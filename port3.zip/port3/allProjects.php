
<?php
$servername = "localhost";
$username = "u-230413184";
$password = "zesaDrN9pdmCaOT";
$dbname = "u_230413184_db";


$con = mysqli_connect($servername, $username, $password, $dbname);


if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT * FROM projects";
$result = mysqli_query($con, $query);


if (!$result) {
    die("Query failed: " . mysqli_error($con));
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style1.css">
    <style>
        /* CSS for navbar */
        .navbar {
            background-color: #ff5e78;
            overflow: hidden;
            width: 100%;
            display: flex;
            justify-content: flex-end;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            padding: 14px 20px;
            display: block;
            transition: background-color 0.3s ease;
        }

        .navbar a:hover {
            background-color: #ff2e52;
        }

        .navbar-right {
            display: flex;
            align-items: center;
        }
        body {
    font-family: Arial, sans-serif;
    background-color: #fce8ed;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #ff5e78;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #ff5e78;
}

input[type="text"],
input[type="password"],
input[type="date"],
select,
textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ff5e78;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type="submit"] {
    width: 100%;
    padding: 10px;
    background-color: #ff5e78;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #ff2e52;
}

/* Table Formatting */
table {
    border-collapse: collapse;
    width: 100%;
    border: 1px solid #ff5e78;
}

th, td {
    border: 1px solid #ff5e78;
    text-align: left;
    padding: 8px;
}

th {
    background-color: #ff5e78;
}

    </style>
    <title>Project List</title>
</head>
<body>
    <!-- Navigation bar -->
    <div class="navbar">
        <div class="navbar-right">
            <a href="projects.html">Search Projects</a>
            <a href="login.html">Login</a>
            <a href="register.html">Register</a>
        </div>
    </div>
    <div class="card-body">
        <table>
            <tr>
                <td>Title</td>
                <td>Start Date</td>
                <td>End Date</td>
                <td>Phase</td>
                <td>Description</td>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['title'] . "</td>";
                echo "<td>" . $row['start_date'] . "</td>";
                echo "<td>" . $row['end_date'] . "</td>";
                echo "<td>" . $row['phase'] . "</td>";
                echo "<td>" . $row['description'] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>    
