<?php

session_start();


$_SESSION = array();


session_destroy();


header("Location: login.html");
exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css\style.css">
    <link rel="stylesheet" type="text/css">
    <title>Log Out</title>
</head>
<body> 
    <h2>You have been logged out</h2>
    <p>Login<a href="login.html"> here</a>.</p>
</body>