// JavaScript for project management system

// Function to handle search form submission
function searchProjects(event) {
    event.preventDefault(); // Prevent default form submission
    
    var searchType = document.getElementById('searchType').value;
    var searchTerm = document.getElementById('searchTerm').value;

    // AJAX request to search projects by name or start date
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                var project = JSON.parse(xhr.responseText);
                displayProjectDetails(project);
            } else {
                console.error('Error:', xhr.status);
            }
        }
    };
    xhr.open('POST', 'search_projects.php');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send('searchType=' + searchType + '&searchTerm=' + searchTerm);
}

// Function to display project details in a new window
function displayProjectDetails(project) {
    // Store project details in localStorage to pass to displayProject.html
    localStorage.setItem('searchedProject', JSON.stringify(project));

    // Open displayProject.html in a new window
    window.open('displayProject.html', '_blank');
}

// Event listener for search form submission
document.getElementById('searchForm').addEventListener('submit', searchProjects);
