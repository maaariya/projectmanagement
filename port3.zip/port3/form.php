<div id="results">
  <?php

  include 'connectdb.php';

  // Function to search projects by name
  function searchProjects($searchTerm) {
    global $conn;

    // Prepare the query to prevent SQL injection
    $query = "SELECT * FROM projects WHERE title LIKE ? OR start_date = ?";
    $stmt = mysqli_prepare($conn, $query);
    $searchTerm = '%' . $searchTerm . '%';
    mysqli_stmt_bind_param($stmt, "ss", $searchTerm, $searchTerm);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $results = array();
    while ($row = mysqli_fetch_assoc($result)) {
      $results[] = $row;
    }

    return $results;
  }

  // validate form
  if (isset($_POST["search"])) {
    $searchTerm = $_POST["search"];
    $results = searchProjects($searchTerm);

  
    if (count($results) > 0) {
      foreach ($results as $r) {
        printf("<div>%s - %s</div>", $r["title"], $r["start_date"]);
      }
    } else {
      echo "No results found";
    }
  }
  ?>
</div>