<?php

$servername = "localhost";
$username = "u-230413184";
$password = "zesaDrN9pdmCaOT";
$dbname = "u_230413184_db";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from the form
$pid = $_POST['pid'];
$title = $_POST['title'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$phase = $_POST['phase'];
$description = $_POST['description'];

// Prepare and execute the SQL statement to update the project
$sql = "UPDATE projects 
        SET title = '$title', 
            start_date = '$start_date', 
            end_date = '$end_date', 
            phase = '$phase', 
            description = '$description' 
        WHERE pid = $pid";

if ($conn->query($sql) === TRUE) {
    // Redirect to success page
    header("Location: success_page2.html");
    exit();
} else {
    // Redirect to error page
    header("Location: error_page.html");
    exit();
}

$conn->close();
?>
