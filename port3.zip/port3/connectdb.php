<?php

$servername = "localhost";
$username = "u-230413184";
$password = "zesaDrN9pdmCaOT";
$dbname = "u_230413184_db";

try {

    $db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    

    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
 
    $db->exec("SET NAMES utf8");
    

    
} catch(PDOException $e) {

    echo "Connection failed: " . $e->getMessage();
}

try {
    $db = new PDO("mysql:host=localhost;dbname=aproject", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Database connection failed: " . $e->getMessage();
    die();
}

?>
