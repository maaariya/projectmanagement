<?php
// (A) DATABASE CONFIG
$servername = "localhost";
$username = "u-230413184";
$password = "zesaDrN9pdmCaOT";
$dbname = "u_230413184_db";

// (B) CONNECT TO DATABASE
try {
  $pdo = new PDO(
    "mysql:host=$servername;dbname=$dbname;charset=utf8mb4",
    $username, $password, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
  );
} catch (PDOException $ex) {
  exit("Connection failed: " . $ex->getMessage());
}

// (C) SEARCH PROJECTS BY START DATE
$stmt = $pdo->prepare("SELECT `title`, `start_date`, `end_date`, `phase`, `description` FROM `projects` WHERE `start_date` LIKE ?");
$stmt->execute(["%".$_POST["search"]."%"]);
$results = $stmt->fetchAll();
if (isset($_POST["ajax"])) { echo json_encode($results); }
?>
